package br.com.impacta.aplicacao;

import javax.swing.JOptionPane;

public class DescontoMensalidade {
	public static void main(String[] args) {
		/*
		 * Em uma escola, o desconto na mensalidade ocorre da seguinte
		 * forma:
		 * 
		 * - Existem dois periodos. Se o periodo for diurno, haver�
		 *   um desconto de 10%
		 * - Al�m disso, se a m�dia final do aluno for superior a 9,
		 *   haver� um desconto de 15%
		 * - Os descontos s�o cumulativos.
		 * 
		 * Escreva um programa que solicite:
		 * - o periodo do aluno (1- diurno, 2- noturno)
		 * - o valor da mensalidade
		 * - a m�dia final
		 * 
		 * Em seguida, apresente:
		 * - o valor da mesalidade
		 * - o valor do desconto
		 * - a mensalidade final
		 * 
		 */
		int periodo = Integer.parseInt(
			JOptionPane.showInputDialog("Periodo (1 ou 2)"));
		
		double mensalidade = Double.parseDouble(
			JOptionPane.showInputDialog("Valor da mensalidade"));
		
		double media = Double.parseDouble(
			JOptionPane.showInputDialog("M�dia final"));
		
		double desconto = 0;
		
		if(periodo == 1) {
			desconto = mensalidade * 0.1;
		}
		
		if(media > 9) {
			desconto += mensalidade * 0.15;
		}
		
		String resposta = "Mensalidade original: " + mensalidade +
						"\nDesconto: " + desconto +
						"\nMensalidade final: " + (mensalidade - desconto);
		
		JOptionPane.showMessageDialog(null, resposta);
	}
}





