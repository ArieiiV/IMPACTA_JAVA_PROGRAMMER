package br.com.impacta.enumeracoes;

public enum Categoria {
	MUNICIPAL, ESTADUAL, FEDERAL
}
