package br.com.impacta.interfaces;

@FunctionalInterface
public interface Processo04<T> {
	int processar(T elemento);
}
