package br.com.impacta.interfaces;

public interface Processo02 {
	void processar(String s, int n);
}
