package br.com.impacta.programa;

public class OperadoresAtribReduzida {
	public static void main(String[] args) {
		int x = 10;
		x += 5;		//x = 15
		x -= 3;		//x = 12
		x *= 2;		//x = 24
		x /= 5;		//x = 4
		x %= 3;		//x = 1
		System.out.println("x : " + x);
		
	}
}
