package br.com.impacta.aplicacao;

import javax.swing.JOptionPane;

public class AppExcecoes04 {
	/*
	 * Se as providencias a serem tomadas quando diversas
	 * exce��es lan�adas forem as mesmas, � prefer�vel que
	 * uma �nica exce��o seja lan�ada.
	 */
	public static void main(String[] args) {
		try {
			String nome = JOptionPane.showInputDialog("Seu nome: ");
			System.out.println("Nome: " + nome.toUpperCase());
				
			int idade = Integer.parseInt(
				JOptionPane.showInputDialog("Sua idade"));		
			System.out.println("Idade: " + idade);
			
			int divisao = 10 / idade;
			System.out.println("Divis�o: " + divisao);
		
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Erro Geral: " + 
				e.getMessage());
		}		
	}
}
