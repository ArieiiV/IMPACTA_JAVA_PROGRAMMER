package br.com.impacta.interfaces;

@FunctionalInterface
public interface Mensagem {
	String calcular(int x);
}
