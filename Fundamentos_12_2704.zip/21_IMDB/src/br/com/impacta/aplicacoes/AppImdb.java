package br.com.impacta.aplicacoes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Comparator;
import java.util.List;

import br.com.impacta.classes.Filme;
import br.com.impacta.util.ImdbUtil;

public class AppImdb {
	
	public static void main(String[] args) {
		
		try {
			
			List<Filme> filmes = ImdbUtil.importFrom("filmes-imdb-ago-2016.csv");
			//filmes.forEach(System.out::println);
			
			//Listar os 5 filmes mais votados
			System.out.println("---- FILMES MAIS VOTADOS - TOP 5 ----");
			filmes.stream()
				  .sorted(Comparator.comparing(Filme::getVotos).reversed())
				  .limit(5)
				  .forEach(System.out::println);
			
			//Listar todos os filmes registrados do Steven Spielberg
			System.out.println("\n---- FILMES DE STEVEN SPIELBERG ----");
			filmes.stream()
			  	  .filter(f -> f.getDiretores().contains("Steven Spielberg"))
			  	  .forEach(System.out::println);
			
		
			//Listar os 20 melhores filmes da lista (maiores notas)
			System.out.println("\n---- MELHORES FILMES - TOP 20 ----");
			filmes.stream()
				  .filter(f -> f.getVotos() > 5000) 
			  	  .sorted(Comparator.comparing(Filme::getNota).reversed())
			  	  .limit(20)
			  	  .forEach(System.out::println);
			
			//Listar os 20 piores filmes da lista (menores notas)
			System.out.println("\n---- PIORES FILMES - TOP 20 ----");
			filmes.stream()
			  	  .filter(f -> f.getVotos() > 5000) 
		  	      .sorted(Comparator.comparing(Filme::getNota))
		  	      .limit(20)
		  	      .forEach(System.out::println);
			
			//Listar os 10 melhores filmes da d�cada de 80
			System.out.println("\n---- OS 10 MELHORES FILMES DA D�CADA DE 80 ----");
			filmes.stream()
				  .filter(f -> f.getAno() >= 1980 && f.getAno() <= 1989)
				  .sorted(Comparator.comparing(Filme::getNota).reversed())
		  	  	  .limit(10)
		  	  	  .forEach(System.out::println);
		
			
			//Exibir a lista de filmes de Tim Burton e a nota m�dia de seus filmes
			System.out.println("\n---- Filmes de Tim Burton e nota m�dia ----");
			filmes.stream()
		  	  	  .filter(f -> f.getDiretores().contains("Tim Burton"))
		  	      .forEach(System.out::println);
			
			double mediaBurton = filmes.stream()
	  	  	  	  				.filter(f -> f.getDiretores().contains("Tim Burton"))
	  	  	  	  				.mapToDouble(f->f.getNota())
	  	  	  	  				.average()
	  	  	  	  				.getAsDouble();
			
			System.out.printf("\n---Nota m�dia de Tim Burton � %.2f--- ", mediaBurton);
			
			//Exportando os dados para a base de dados do IMDB
			export(filmes);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void export(List<Filme> filmes) throws Exception {
		
		if(exported(filmes)) {
			System.out.println("Dados j� exportados!");
			return;
		}
		
		//codigo para importar todos os filmes da lista
		Connection con = getConnection();
		String insert = "insert into tb_filme "
							+ "(titulo, diretores, generos, nota, votos, duracao, ano) "
							+ "values (?,?,?,?,?,?,?)";
		
		PreparedStatement ps = con.prepareStatement(insert);
		
		for(Filme filme : filmes) {
			ps.setString(1, filme.getTitulo());
			ps.setString(2, filme.getDiretores());
			ps.setString(3, filme.getGeneros());
			ps.setDouble(4, filme.getNota());
			ps.setInt(5, filme.getVotos());
			ps.setInt(6, filme.getDuracao());
			ps.setInt(7, filme.getAno());
			
			ps.execute();
		}
		ps.close();
		closeConnection(con);
	}

	private static boolean exported(List<Filme> filmes) {
		Connection con = null;
		try {
			con = getConnection();
			PreparedStatement ps = con.prepareStatement("select count(*) from tb_filme");
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				int linhas = rs.getInt(1);
				if(linhas >= filmes.size()) {
					return true;
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con);
		}
		return false;
	}

	private static void closeConnection(Connection con) {
		try {
			if(!con.isClosed()) {
				con.close();
			}
		}catch(Exception e) {
			//ignora por nao ter o que fazer aqui...
		}
	}

	private static Connection getConnection() {
		Connection conexao = null;
		String url = "jdbc:mysql://localhost:3306/IMDB";
		String usuario = "root";
		String senha = "Imp@ct@";
		
		try {
			conexao = DriverManager.getConnection(url,usuario,senha);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return conexao;
	}

}
