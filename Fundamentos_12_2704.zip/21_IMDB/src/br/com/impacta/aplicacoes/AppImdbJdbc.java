package br.com.impacta.aplicacoes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AppImdbJdbc {
	
	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/IMDB";
		String usuario = "root";
		String senha = "Imp@ct@";
		
		try {
			
			Connection conexao = DriverManager.getConnection(url,usuario,senha);
			System.out.println("Conex�o estabelecida com sucesso...");
			
			//Exemplo de comando basico
			Statement stmt = conexao.createStatement();
			String sql1 = "insert into tb_filme(titulo,diretores,generos) "
						    + "values (\'Meu Filme\',\'Eu\', \'teste\') ";
			
			stmt.execute(sql1);
			stmt.close();
			
			//Exemplo de comando pre-compilado
			String sql2 = "insert into tb_filme(titulo,diretores,generos) values (?,?,?)"; 
			PreparedStatement ps = conexao.prepareStatement(sql2);
			ps.setString(1,"Meu Filme II");
			ps.setString(2, "Eu de novo");
			ps.setString(3, "teste II");
			
			ps.execute();
			ps.close();
			
			//Consultando 
			String sql3 = "select * from tb_filme";
			ps = conexao.prepareStatement(sql3);
			
			ResultSet view = ps.executeQuery();
			while(view.next()) {
				int id = view.getInt("ID");
				String titulo =  view.getString("titulo");
				String diretores = view.getString("diretores");
				String generos = view.getString("generos");
				
				System.out.printf("%d %-20s %-20s %-20s \n",id,titulo,diretores,generos);
			}
			
			//limpando todos os dados da tabela
			String remove = "delete from tb_filme";
			ps = conexao.prepareStatement(remove);
			ps.execute();
			
			ps.close();
			conexao.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}

}
