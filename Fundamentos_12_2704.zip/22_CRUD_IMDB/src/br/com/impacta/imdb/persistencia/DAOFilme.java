package br.com.impacta.imdb.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.impacta.imdb.modelo.Filme;

public class DAOFilme {

	public void inserir(Filme filme) throws Exception {
		Connection con = getConnection();
		String insert = "insert into tb_filme " + "(titulo, diretores, generos, "
							+ "nota, votos, duracao, ano) "
							+ "values (?,?,?,?,?,?,?)";

		PreparedStatement ps = con.prepareStatement(insert);

		ps.setString(1, filme.getTitulo());
		ps.setString(2, filme.getDiretores());
		ps.setString(3, filme.getGeneros());
		ps.setDouble(4, filme.getNota());
		ps.setInt(5, filme.getVotos());
		ps.setInt(6, filme.getDuracao());
		ps.setInt(7, filme.getAno());

		ps.execute();
		ps.close();

		closeConnection(con);

	}

	public void remover(Filme filme) throws Exception {
		Connection con = getConnection();
		String delete = "delete from tb_filme where id = ?";
		PreparedStatement ps = con.prepareStatement(delete);
		ps.setInt(1, filme.getId());

		ps.execute();
		ps.close();
		closeConnection(con);
	}

	public void alterar(Filme filme) throws Exception {
		Connection con = getConnection();
		String update = "update tb_filme set "
							+ "titulo = ? , "
							+ "diretores = ? , "
							+ "generos = ? , "
							+ "nota = ? , "
							+ "votos = ? , "
							+ "duracao = ? , "
							+ "ano = ?  "
							+ "where id = ? "; 

		PreparedStatement ps = con.prepareStatement(update);

		ps.setString(1, filme.getTitulo());
		ps.setString(2, filme.getDiretores());
		ps.setString(3, filme.getGeneros());
		ps.setDouble(4, filme.getNota());
		ps.setInt(5, filme.getVotos());
		ps.setInt(6, filme.getDuracao());
		ps.setInt(7, filme.getAno());
		ps.setInt(8, filme.getId());

		ps.execute();
		ps.close();

		closeConnection(con);
	}

	public List<Filme> getAll() throws Exception {
		List<Filme> filmes = new ArrayList<>();
		Connection con = getConnection();
		String select = "select * from tb_filme";
		PreparedStatement ps = con.prepareStatement(select);
		
		ResultSet result = ps.executeQuery();
		while(result.next()) {
			Filme filme = new Filme(result.getInt("id"),
									result.getString("titulo"),
									result.getString("diretores"),
									result.getDouble("nota"),
									result.getInt("duracao"),
									result.getInt("ano"),
									result.getString("generos"),
									result.getInt("votos"),
									null, null);
			filmes.add(filme);
		}
		
		return filmes;		
	}
	
	private static void closeConnection(Connection con) {
		try {
			if(!con.isClosed()) {
				con.close();
			}
		}catch(Exception e) {
			//ignora por nao ter o que fazer aqui...
		}
	}

	private static Connection getConnection() {
		Connection conexao = null;
		String url = "jdbc:mysql://localhost:3306/IMDB";
		String usuario = "root";
		String senha = "Imp@ct@";
		
		try {
			conexao = DriverManager.getConnection(url,usuario,senha);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return conexao;
	}

}
