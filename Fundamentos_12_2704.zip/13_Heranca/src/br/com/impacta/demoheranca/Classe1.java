package br.com.impacta.demoheranca;

public class Classe1 {
	public Classe1() {
		super();
		System.out.println("Estamos na classe 1");
	}
}
