package br.com.impacta.demoheranca;

public class Classe2 extends Classe1 {
	public Classe2() {
		super();
		System.out.println("Estamos na classe 2");
	}
}
