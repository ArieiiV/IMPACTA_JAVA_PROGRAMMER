package br.com.impacta.programa;

public class VariaveisLogicas {
	public static void main(String[] args) {
		boolean b1 = true;
		boolean b2 = false;
		
		boolean b3 = (5 > 3);
		boolean b4 = (-1 > -2);
		
		System.out.println("b1: " + b1);
		System.out.println("b2: " + b2);
		System.out.println("b3: " + b3);
		System.out.println("b4: " + b4);
	}
}
