package br.com.impacta.imdb.utilitario;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class FilmesUtil {

	public static Set<String> extrairGeneros(List<String> generos) {
		Set<String> setGeneros = new TreeSet<>();
		for(String linhaGenero : generos) {
			String[] splittedGeneros = linhaGenero.split("\\s*,\\s*"); //qualquer quantidade de espa�os antes ou depois da virgula que separa os generos
			for (String genero : splittedGeneros) {
				setGeneros.add(genero);	
			}
		}
		
		return setGeneros;
	}

}
