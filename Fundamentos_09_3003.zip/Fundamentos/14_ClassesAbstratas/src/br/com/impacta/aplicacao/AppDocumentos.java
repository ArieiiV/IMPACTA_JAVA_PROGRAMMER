package br.com.impacta.aplicacao;

import javax.swing.JOptionPane;

import br.com.impacta.classes.DocCnpj;
import br.com.impacta.classes.Documento;

public class AppDocumentos {
	public static void main(String[] args) {
		Documento cpf = new DocCnpj();
		cpf.setNumero("11122233340000");
		JOptionPane.showMessageDialog(null, cpf.exibir());
	}
}
