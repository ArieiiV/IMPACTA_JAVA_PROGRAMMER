package br.com.impacta.interfaces;

public interface Figura {
	
	/*
	 * todos os atributos de uma interface s�o
	 * p�blicos, est�ticos e constantes (final) por defini��o
	 */
	String DESCRICAO = "Interface Figura: deve ser implementada";
	/*
	 * todos os m�todos de uma interface s�o 
	 * publicos e abstratos por defini��o
	 */
	double calcularArea();
	
	default String exibirFigura() {
		String resposta = "Classe: " + this.getClass().getSimpleName() +
				"\n�rea da figura: " + this.calcularArea();
		return resposta;
	}
}










