package br.com.impacta.aplicacao;

import java.util.ArrayList;
import java.util.List;

public class AppList01 {
	public static void main(String[] args) {
		//Lista de nomes
		List<String> nomes = new ArrayList<>();
		
		//adicionando elementos na lista
		nomes.add("Miguel");
		nomes.add("Jonas");
		nomes.add("Patricia");
		nomes.add("Miguel");
		nomes.add("Gerson");
		
		nomes.add(0, "Basilio"); //adicionando um nome na posi��o 0
		
		nomes.remove(nomes.size() - 1); //remove o ultimo elemento
		
		//removendo os elementos que come�am com a letra A
		nomes.removeIf(s -> s.startsWith("A"));
		
		//apresentando os nomes atrav�s de express�es lambda
		nomes.forEach(s -> System.out.println(s));
		
		
		
		
		
		
		
		
	}
}
