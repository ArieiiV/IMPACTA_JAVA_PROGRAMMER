package br.com.impacta.aplicacao;

import java.util.LinkedHashSet;
import java.util.Set;

public class AppSet01 {
	public static void main(String[] args) {
		//Lista de nomes
		Set<String> nomes = new LinkedHashSet<>();
		
		//adicionando elementos na lista
		nomes.add("Miguel");
		nomes.add("Jonas");
		nomes.add("Patricia");
		nomes.add("Miguel");
		nomes.add("Gerson");
		
		//removendo os elementos que come�am com a letra A
		nomes.removeIf(s -> s.startsWith("A"));
		
		//apresentando os nomes atrav�s de express�es lambda
		nomes.forEach(s -> System.out.println(s));
		
	}
}
