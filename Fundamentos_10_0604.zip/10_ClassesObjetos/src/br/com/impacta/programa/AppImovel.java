package br.com.impacta.programa;

import javax.swing.JOptionPane;

import br.com.impacta.classes.exercicios.Imovel;

public class AppImovel {
	
	public static void main(String[] args) {
		Imovel imovel1 = new Imovel();
		imovel1.descricao = "Casa com porta de entrada";
		imovel1.area = 55;
		imovel1.endereco = "Rua da Pedra Grande, 1000";
		
		String resposta = "Descri��o: " + imovel1.descricao +
							"\n�rea: " + imovel1.area +
							"\nEndere�o: " + imovel1.endereco;
		
		JOptionPane.showMessageDialog(null, resposta);
		
		Imovel imovel2 = new Imovel();
		imovel2.descricao = "Apartamento completo";
		imovel2.area = 220;
		imovel2.endereco = "Rua do Ipe, 230";
		
		resposta = "Descri��o: " + imovel1.descricao +
				"\n�rea: " + imovel1.area +
				"\nEndere�o: " + imovel1.endereco;

		JOptionPane.showMessageDialog(null, resposta);		
	}
}
