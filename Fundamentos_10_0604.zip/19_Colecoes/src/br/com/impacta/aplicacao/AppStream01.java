package br.com.impacta.aplicacao;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Stream;

import br.com.impacta.classes.Curso;

public class AppStream01 {
	
	public static void main(String[] args) {
		Set<Curso> cursos = new TreeSet<>();
		
		//criando as diferentes inst�ncias...
		Curso c0 = new Curso("Hist�ria da Arte", 40, 765.45);
		Curso c1 = new Curso("Cinema e Pol�tica", 25, 234.51);
		Curso c2 = new Curso("Express�o Verbal", 60, 1013.44);
		Curso c3 = new Curso("Estrutura de Dados", 80, 1500.02);
		Curso c4 = new Curso("Algoritmos", 88, 1865.98);
		Curso c5 = new Curso("Bases da Economia", 44, 812.55);
		Curso c6 = new Curso("Matem�tica Financeira", 140, 2200.87);
		Curso c7 = new Curso("Reiki n�vel 1", 16, 334.56);
		Curso c8 = new Curso("Astrologia B�sica", 100, 888.88);
		Curso c9 = new Curso("Dire��o Defensiva", 25, 356.65);
		
		//Adicionando as inst�ncias na cole��o
		cursos.add(c0);
		cursos.add(c1);
		cursos.add(c2);
		cursos.add(c3);
		cursos.add(c4);
		cursos.add(c5);
		cursos.add(c6);
		cursos.add(c7);
		cursos.add(c8);
		cursos.add(c9);
		
		//Obtendo um stream de cursos
		Stream<Curso> streamCurso = cursos.stream();
		
		//streamCurso.limit(2)
		//streamCurso.skip(4)
		//streamCurso.sorted()
		//streamCurso.sorted(Comparator.comparing(Curso::getPreco))
		//streamCurso.filter(c -> c.getPreco() > 1000)
		//		   .forEach(System.out::println);
		
//		Curso cursoMaisDemorado = streamCurso.max
//									(Comparator.comparing(Curso::getCargaHoraria))
//									.get();
//		
//		System.out.println("--- Curso com maior carga hor�ria ---");
//		System.out.println(cursoMaisDemorado);
		
		//listagem dos cursos com carga horaria entre 30 e 60 horas
		streamCurso.filter(c -> (c.getCargaHoraria() >= 30 && c.getCargaHoraria() <=60 ))
				   .forEach(System.out::println);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

		
	}

}
