package br.com.impacta.aplicacao;

import javax.swing.JOptionPane;

public class AppExcecoes03 {
	/*
	 * Podemos ter v�rios blocos catch(), incluindo o bloco que 
	 * captura Exception. Neste caso, temos que ser cuidadosos para
	 * que uma exce��o representando uma superclasse (Exception)
	 * n�o capture as exce��es das possiveis subclasses.
	 * 
	 */
	public static void main(String[] args) {
		try {
			String nome = JOptionPane.showInputDialog("Seu nome: ");
			System.out.println("Nome: " + nome.toUpperCase());
				
			int idade = Integer.parseInt(
				JOptionPane.showInputDialog("Sua idade"));		
			System.out.println("Idade: " + idade);
			
			int divisao = 10 / idade;
			System.out.println("Divis�o: " + divisao);
		
		} catch(NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "Erro de convers�o: " + 
				e.getMessage());
		
		} catch(NullPointerException e) {
			JOptionPane.showMessageDialog(null, "Erro de ref. nula: " + 
				e.getMessage());
		
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Erro Geral: " + 
				e.getMessage());
		}
	}
}






