package br.com.impacta.imdb.apresentacao.swing;

public class TelaPrincipal {

	public static void main(String[] args) {
		new ListaFilmesFrame();
	}
}
